import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

# Load the split data
X_train = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_train.csv')
y_train = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_train.csv')

# Ensure target variable is correctly shaped
y_train = y_train.values.ravel()

# Best hyperparameters found during tuning
best_params = {'criterion': 'gini', 'max_depth': 19, 'min_samples_split': 10, 'min_samples_leaf': 6}

# Initialize the model with the best hyperparameters
model = RandomForestClassifier(**best_params, random_state=42)

# Perform cross-validation
cv_scores = cross_val_score(model, X_train, y_train, cv=5)
print(f"Cross-validation scores: {cv_scores}")
print(f"Mean cross-validation score: {np.mean(cv_scores)}")
