from flask import Flask, send_from_directory
from flask_swagger_ui import get_swaggerui_blueprint
from flask_cors import CORS
import os

app = Flask(__name__, static_folder='../static')
CORS(app)

# Print working directory and files for debugging
print("Current working directory:", os.getcwd())
print("Files in current directory:", os.listdir())
print("Static directory contents:", os.listdir(os.path.join(os.getcwd(), '../static')))

# Swagger setup
SWAGGER_URL = '/swagger'
API_URL = '/swagger.json'
swaggerui_blueprint = get_swaggerui_blueprint(SWAGGER_URL, API_URL, config={'app_name': "Crypto Trading Bot API"})
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

# Serve the swagger.json file
@app.route('/swagger.json')
def swagger_json():
    static_dir = os.path.join(app.root_path, '../static')
    print("Serving swagger.json from:", static_dir)
    return send_from_directory(static_dir, 'swagger.json')

# A simple route to check if the server is running
@app.route('/status', methods=['GET'])
def status():
    return {"status": "API is running"}

if __name__ == '__main__':
    app.run(debug=True)
