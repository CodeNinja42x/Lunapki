import sys
import os
import subprocess

# Ensure the virtual environment is activated
venv_activate = '/Users/gorkemberkeyuksel/.pyenv/versions/lunapki-env-3.10/bin/activate_this.py'
if 'VIRTUAL_ENV' not in os.environ:
    if os.path.exists(venv_activate):
        exec(open(venv_activate).read(), {'__file__': venv_activate})
    else:
        print(f"Error: Virtual environment activation script not found at {venv_activate}")
        sys.exit(1)

# Run the main script
script_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/scripts2/train.py'
subprocess.run([sys.executable, script_path])
