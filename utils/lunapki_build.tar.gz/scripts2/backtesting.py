import pandas as pd
import lightgbm as lgb
from sklearn.metrics import roc_auc_score

def backtest(model, data):
    data['prediction'] = model.predict(data.drop('target', axis=1))
    data['strategy_returns'] = data['prediction'] * data['returns']
    return data['strategy_returns'].cumsum()

if __name__ == "__main__":
    model = lgb.Booster(model_file='models/best_lightgbm_model.txt')
    data = pd.read_csv('data/crypto_data_with_indicators.csv')
    data['returns'] = data['close'].pct_change()
    backtest_results = backtest(model, data)
    print("Backtesting results:")
    print(backtest_results)
