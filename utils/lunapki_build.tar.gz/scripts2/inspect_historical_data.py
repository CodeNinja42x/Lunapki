import pandas as pd

# Load the historical data
data_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/btc_usdt_historical_data.csv'
historical_data = pd.read_csv(data_path)

# Display the first few rows of the dataset
print("First few rows of the historical data:")
print(historical_data.head())

# Display the data types and check for missing values
print("\nData types and missing values:")
print(historical_data.info())
print(historical_data.isnull().sum())
