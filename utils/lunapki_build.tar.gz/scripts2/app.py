from flask import Flask, request, jsonify, send_from_directory
import joblib
import pandas as pd
import logging
from functools import wraps
from flask_swagger_ui import get_swaggerui_blueprint
from flask_cors import CORS
import os

app = Flask(__name__, static_folder='static')
CORS(app)

# Setup logging
logging.basicConfig(level=logging.INFO)

# Log the current working directory
logging.info(f"Current working directory: {os.getcwd()}")
logging.info(f"Static directory contents: {os.listdir('static')}")

# Load the trained model
model = joblib.load('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/best_model.pkl')

# Swagger setup
SWAGGER_URL = '/swagger'
API_URL = '/swagger.json'
swaggerui_blueprint = get_swaggerui_blueprint(SWAGGER_URL, API_URL, config={'app_name': "Crypto Trading Bot API"})
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

# Serve the swagger.json file
@app.route('/swagger.json')
def swagger_json():
    return send_from_directory(app.static_folder, 'swagger.json')

# Basic Auth Decorator
def check_auth(username, password):
    return username == 'admin' and password == 'secret'

def authenticate():
    message = {'message': "Authenticate."}
    resp = jsonify(message)
    resp.status_code = 401
    return resp

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route('/predict', methods=['POST'])
@requires_auth
def predict():
    """
    Predict the outcome based on financial data.
    ---
    tags:
      - Prediction
    parameters:
      - in: body
        name: body
        description: Financial data for prediction
        required: true
        schema:
          type: array
          items:
            type: object
            properties:
              open:
                type: number
                example: 100
              high:
                type: number
                example: 110
              low:
                type: number
                example: 90
              close:
                type: number
                example: 105
              volume:
                type: number
                example: 1500
              SMA:
                type: number
                example: 102
              EMA:
                type: number
                example: 103
              RSI:
                type: number
                example: 60
              Bollinger_High:
                type: number
                example: 115
              Bollinger_Low:
                type: number
                example: 85
              RSI_diff:
                type: number
                example: 5
              SMA_diff:
                type: number
                example: 2
    responses:
      200:
        description: Predictions
        schema:
          type: array
          items:
            type: integer
            example: 0
    """
    data = request.json
    df = pd.DataFrame(data)
    features = ['open', 'high', 'low', 'close', 'volume', 'SMA', 'EMA', 'RSI', 'Bollinger_High', 'Bollinger_Low', 'RSI_diff', 'SMA_diff']
    df = df[features]
    predictions = model.predict(df)
    logging.info(f"Received data: {data}")
    logging.info(f"Predictions: {predictions.tolist()}")
    return jsonify(predictions.tolist())

@app.route('/status', methods=['GET'])
def status():
    """
    Check the status of the API.
    ---
    tags:
      - Status
    responses:
      200:
        description: API status
        schema:
          type: object
          properties:
            status:
              type: string
              example: API is running
    """
    return jsonify({"status": "API is running"})

if __name__ == '__main__':
    app.run(debug=True)
