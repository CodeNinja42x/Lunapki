# check_raw_data.py
import pandas as pd

# Load the raw data
raw_data = pd.read_csv('data/raw_data.csv')

# Print the columns to see what's available
print(raw_data.columns)
