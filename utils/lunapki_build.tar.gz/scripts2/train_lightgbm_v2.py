# scripts2/train_lightgbm_v2.py
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_squared_error

# Load data
data = pd.read_csv('data/processed_data_with_features.csv')

# Define your target column (adjust if necessary)
target_column = 'Price_Range'  # Ensure this matches your actual target column name
X = data.drop(columns=[target_column, 'timestamp'])
y = data[target_column]

# Split data into training and validation sets
train_data = lgb.Dataset(X, label=y)

# Define parameters based on hyperparameter tuning
params = {
    'objective': 'regression',
    'learning_rate': 0.1,
    'num_leaves': 31,
    'min_data_in_leaf': 30,
    'max_depth': -1,
    'metric': 'rmse'
}

# Train model
gbm = lgb.train(params, train_data, num_boost_round=100, valid_sets=[train_data], early_stopping_rounds=10)

# Predict on training data
y_pred = gbm.predict(X, num_iteration=gbm.best_iteration)

# Calculate RMSE
rmse = mean_squared_error(y, y_pred, squared=False)
print(f"RMSE: {rmse}")

# Save model
gbm.save_model('lightgbm_model.txt')
