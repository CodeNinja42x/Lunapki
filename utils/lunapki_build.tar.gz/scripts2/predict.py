import pandas as pd
import joblib

# Paths
new_data_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/new_data.csv'
model_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/LightGBM_model.pkl'

# Load new data
new_data = pd.read_csv(new_data_path)

# Calculate necessary features
new_data['MA_5'] = new_data['close'].rolling(window=5).mean()
new_data['MA_10'] = new_data['close'].rolling(window=10).mean()
new_data['STD_5'] = new_data['close'].rolling(window=5).std()
new_data['Return'] = new_data['close'].pct_change()

# Drop any rows with NaN values (if any)
new_data = new_data.dropna()

# Ensure columns are in the correct order
X_new = new_data[['open', 'high', 'low', 'close', 'volume', 'MA_5', 'MA_10', 'STD_5', 'Return']]

# Load the model
best_model = joblib.load(model_path)

# Make predictions
predictions = best_model.predict(X_new)
print("Predictions:", predictions)
