import lightgbm as lgb
import pandas as pd
from sklearn.metrics import log_loss, accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split

# Load your dataset with new features
df = pd.read_csv('your_dataset_with_new_features.csv')  # Update this line with your actual dataset path

# Split data into features and target
X = df.drop(columns=['target'])
y = df['target']

# Split data into training and unseen test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Set up LightGBM dataset
d_train = lgb.Dataset(X_train, label=y_train)
d_test = lgb.Dataset(X_test, label=y_test)

# LightGBM parameters
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'learning_rate': 0.01,
    'num_leaves': 108,
    'max_depth': 7,
    'min_data_in_leaf': 52,
    'colsample_bytree': 0.7,
    'subsample': 0.67,
    'reg_alpha': 6.4,
    'reg_lambda': 0.064
}

# Train model with cross-validation
cv_results = lgb.cv(params, d_train, num_boost_round=2000, nfold=5, early_stopping_rounds=10, verbose_eval=100)

# Evaluate on unseen test data
model = lgb.train(params, d_train, num_boost_round=len(cv_results['binary_logloss-mean']))
y_pred = model.predict(X_test)

# Calculate metrics
test_log_loss = log_loss(y_test, y_pred)
test_accuracy = accuracy_score(y_test, (y_pred > 0.5).astype(int))
test_roc_auc = roc_auc_score(y_test, y_pred)

print(f"Test Log Loss: {test_log_loss}")
print(f"Test Accuracy: {test_accuracy}")
print(f"Test ROC AUC: {test_roc_auc}")
