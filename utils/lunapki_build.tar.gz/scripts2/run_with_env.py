import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
import lightgbm as lgb
import xgboost as xgb
import joblib

# Debugging imports
from utils import data_processing
print(dir(data_processing))  # This will list all the available functions and variables in data_processing module

# If 'preprocess_data' is in the list, it should be imported correctly
from utils.data_processing import preprocess_data

# Load and preprocess your data
data_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'training_data.csv'))
try:
    data = pd.read_csv(data_path)
except Exception as e:
    print(f"Error loading data: {e}")
    sys.exit(1)

print("First few rows of data:")
print(data.head())

data = preprocess_data(data)  # Example function, replace with your actual preprocessing function

# Basic data preprocessing
X = data.drop(columns=['target'])  # Replace 'target' with your target column name
y = data['target']

print("Target distribution:")
print(y.value_counts())

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print("X_train shape:", X_train.shape)
print("y_train shape:", y_train.shape)
print("X_test shape:", X_test.shape)
print("y_test shape:", y_test.shape)
print("First few rows of X_train:")
print(X_train.head())
print("First few rows of y_train:")
print(y_train.head())

# Train LightGBM model
lgb_model = lgb.LGBMClassifier()
lgb_model.fit(X_train, y_train)
lgb_preds = lgb_model.predict(X_test)
print("LightGBM Accuracy:", accuracy_score(y_test, lgb_preds))
print("LightGBM F1 Score:", f1_score(y_test, lgb_preds, average='macro'))
print("LightGBM Precision:", precision_score(y_test, lgb_preds, average='macro'))
print("LightGBM Recall:", recall_score(y_test, lgb_preds, average='macro'))

# Save the model
joblib.dump(lgb_model, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models', 'lgb_model.pkl')))

# Train XGBoost model
xgb_model = xgb.XGBClassifier()
xgb_model.fit(X_train, y_train)
xgb_preds = xgb_model.predict(X_test)
print("XGBoost Accuracy:", accuracy_score(y_test, xgb_preds))
print("XGBoost F1 Score:", f1_score(y_test, xgb_preds, average='macro'))
print("XGBoost Precision:", precision_score(y_test, xgb_preds, average='macro'))
print("XGBoost Recall:", recall_score(y_test, xgb_preds, average='macro'))

# Save the model
joblib.dump(xgb_model, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models', 'xgb_model.pkl')))
