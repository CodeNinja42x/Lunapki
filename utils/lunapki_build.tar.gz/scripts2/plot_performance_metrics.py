import matplotlib.pyplot as plt
import pickle

# Load CV results
with open('cv_results.pkl', 'rb') as f:
    cv_results = pickle.load(f)

# Plot log loss
plt.figure(figsize=(10, 5))
plt.plot(cv_results['binary_logloss-mean'], label='Validation Log Loss')
plt.xlabel('Number of Boosting Rounds')
plt.ylabel('Log Loss')
plt.title('Validation Log Loss Over Boosting Rounds')
plt.legend()
plt.show()
