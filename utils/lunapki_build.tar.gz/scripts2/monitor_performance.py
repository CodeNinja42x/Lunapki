import pandas as pd
import joblib
from sklearn.metrics import accuracy_score, roc_auc_score

# Load the data
X_test = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_test.csv')
y_test = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_test.csv')

# Define the feature set (same as used during training)
features = ['open', 'high', 'low', 'close', 'volume', 'SMA', 'EMA', 'RSI', 'Bollinger_High', 'Bollinger_Low', 'RSI_diff', 'SMA_diff']

X_test = X_test[features]

# Load the model
model = joblib.load('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/best_model.pkl')

# Make predictions
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")
print(f"ROC AUC: {roc_auc}")
