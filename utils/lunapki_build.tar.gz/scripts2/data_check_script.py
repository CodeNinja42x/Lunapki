import pandas as pd

# Load the data
X_test = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_test.csv')
y_test = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_test.csv')

# Check shapes
print(f"X_test shape: {X_test.shape}")
print(f"y_test shape: {y_test.shape}")

# Check data length matches
if len(X_test) == len(y_test):
    print("Data length matches.")
else:
    print("Data length does not match.")

# Check first few rows of y_test
print("First few rows of y_test:")
print(y_test.head())

# Check class distribution
print("Class distribution in y_test:")
print(y_test['target'].value_counts())
