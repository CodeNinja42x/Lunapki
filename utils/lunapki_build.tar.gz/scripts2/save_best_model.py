import pandas as pd
import joblib
from lightgbm import LGBMClassifier

# Load your data
data_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/actual_data.csv'  # Replace with your actual data file path
data = pd.read_csv(data_path)

# Split the data into features and target
X = data.drop(columns='target_column')  # Replace 'target_column' with your actual target column name
y = data['target_column']  # Replace 'target_column' with your actual target column name

# Load your best model
model_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/LightGBM_model.pkl'
best_model = joblib.load(model_path)

# Train the model on the full dataset
best_model.fit(X, y)

# Save the updated model
joblib.dump(best_model, model_path)

print("Model has been trained and saved successfully.")
