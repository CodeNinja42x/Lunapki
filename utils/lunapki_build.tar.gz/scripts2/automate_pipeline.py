import os
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
import ta

# Function to generate more data if needed
def add_more_data(existing_data_size):
    additional_data = []
    base_date = pd.to_datetime('2024-07-01')
    base_close = 35000
    base_volume = 1000

    for i in range(existing_data_size, existing_data_size + 500):
        date = base_date + pd.DateOffset(days=i)
        close = base_close + i * 50
        volume = base_volume + i * 10
        additional_data.append([date.strftime('%Y-%m-%d'), close, volume])
    
    additional_df = pd.DataFrame(additional_data, columns=['date', 'close', 'volume'])
    return additional_df

# Check if dataset has enough data
def check_data():
    dataset_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset.csv'
    if not os.path.exists(dataset_path):
        df = add_more_data(0)
        df.to_csv(dataset_path, index=False)
    df = pd.read_csv(dataset_path)
    while len(df) < 1000:  # Assuming 1000 rows is sufficient for training
        additional_df = add_more_data(len(df))
        df = pd.concat([df, additional_df], ignore_index=True)
        df.to_csv(dataset_path, index=False)

# Feature Engineering
def feature_engineering():
    df = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset.csv')
    df['return'] = df['close'].pct_change()
    df['volatility'] = df['return'].rolling(window=10).std()
    df['momentum'] = df['close'] - df['close'].shift(10)
    df['ma50'] = df['close'].rolling(window=50).mean()
    df['ma200'] = df['close'].rolling(window=200).mean()
    df['rsi'] = ta.momentum.rsi(df['close'], window=14)
    df['macd'] = ta.trend.macd(df['close'])
    df['macd_signal'] = ta.trend.macd_signal(df['close'])
    df = df.fillna(0)
    df.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset_engineered.csv', index=False)

# Training the model
def train_model():
    df = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset_engineered.csv')
    X = df[['return', 'volatility', 'momentum', 'ma50', 'ma200', 'rsi', 'macd', 'macd_signal']]
    y = (df['close'].shift(-1) > df['close']).astype(int)  # Predict if the next day's close price will be higher

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = lgb.LGBMClassifier(min_data_in_leaf=20, min_sum_hessian_in_leaf=10)
    model.fit(X_train, y_train)
    model.booster_.save_model('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/model.txt')

# Backtesting
def backtest_model():
    df = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset_engineered.csv')
    model = lgb.Booster(model_file='/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/model.txt')
    X = df[['return', 'volatility', 'momentum', 'ma50', 'ma200', 'rsi', 'macd', 'macd_signal']]
    y = (df['close'].shift(-1) > df['close']).astype(int)
    predictions = model.predict(X)
    df['predictions'] = predictions
    df.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_backtest_results.csv', index=False)

# Deploy the model
def deploy_model():
    df = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_dataset_engineered.csv')
    model = lgb.Booster(model_file='/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/model.txt')
    X = df[['return', 'volatility', 'momentum', 'ma50', 'ma200', 'rsi', 'macd', 'macd_signal']]
    predictions = model.predict(X)
    df['predictions'] = predictions
    df.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/your_deployment_results.csv', index=False)

if __name__ == "__main__":
    check_data()
    feature_engineering()
    train_model()
    backtest_model()
    deploy_model()
