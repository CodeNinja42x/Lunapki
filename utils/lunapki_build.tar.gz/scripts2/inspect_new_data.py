import pandas as pd

# Define the path to the new data file
new_data_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/new_data.csv'  # Replace with your new data file path

# Load the new data
new_data = pd.read_csv(new_data_path)

# Print the column names
print(new_data.columns)
