import pandas as pd
import lightgbm as lgb
from sklearn.metrics import mean_squared_error
from math import sqrt

# Load the training data
train_data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/enhanced_train_data.csv')

# Prepare the features and target
X_train = train_data.drop(columns=['target', 'timestamp'])
y_train = train_data['target']

# Initialize the model with the best parameters found
params = {
    'learning_rate': 0.1,
    'max_depth': -1,
    'min_data_in_leaf': 30,
    'num_leaves': 31,
    'objective': 'regression'
}

# Train the model
train_set = lgb.Dataset(X_train, label=y_train)
model = lgb.train(params, train_set, num_boost_round=100)

# Evaluate on training data
train_preds = model.predict(X_train)
train_rmse = sqrt(mean_squared_error(y_train, train_preds))
print(f'Training RMSE: {train_rmse}')
