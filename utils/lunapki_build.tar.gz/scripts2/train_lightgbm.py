import lightgbm as lgb
from lightgbm import early_stopping
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score
from imblearn.over_sampling import SMOTE
import joblib

# Load data
data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/processed_data_with_features.csv')

# Create a dummy target column (1 if Change > 0, else 0)
data['target'] = (data['Change'] > 0).astype(int)

# Separate features and target
X = data.drop(['target', 'timestamp'], axis=1)  # Assuming 'timestamp' is not a feature
y = data['target']

# Ensure there's no data leakage
assert not any(X.isna().any()), "Feature data contains NaN values"
assert not y.isna().any(), "Target data contains NaN values"

# Apply SMOTE to balance the dataset
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# Split data
X_train, X_valid, y_train, y_valid = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42, shuffle=True, stratify=y_resampled)

# Check for class balance in training and validation sets
print(f"Training set class distribution:\n{y_train.value_counts()}")
print(f"Validation set class distribution:\n{y_valid.value_counts()}")

# Prepare datasets for LightGBM
train_data = lgb.Dataset(X_train, label=y_train)
valid_data = lgb.Dataset(X_valid, label=y_valid, reference=train_data)

# Define parameters with more regularization and smaller learning rate
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'learning_rate': 0.0005,
    'num_leaves': 5,
    'max_depth': 2,
    'min_data_in_leaf': 30,
    'feature_fraction': 0.7,
    'bagging_fraction': 0.7,
    'bagging_freq': 5,
    'lambda_l1': 2.0,  # Further increase L1 regularization
    'lambda_l2': 2.0,  # Further increase L2 regularization
    'drop_rate': 0.5,  # Introduce dropout
    'verbose': -1  # To suppress warnings during training
}

# Perform cross-validation
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_results = lgb.cv(params, train_data, num_boost_round=2000, nfold=5, stratified=True, early_stopping_rounds=10, verbose_eval=True)

# Train the final model
model = lgb.train(
    params, 
    train_data, 
    num_boost_round=2000, 
    valid_sets=[train_data, valid_data], 
    valid_names=['train', 'valid'],
    callbacks=[early_stopping(stopping_rounds=10)]
)

# Make predictions
y_pred = model.predict(X_valid, num_iteration=model.best_iteration)
y_pred_binary = [1 if pred > 0.5 else 0 for pred in y_pred]

# Evaluate model
accuracy = accuracy_score(y_valid, y_pred_binary)
roc_auc = roc_auc_score(y_valid, y_pred)

print(f'Accuracy: {accuracy}')
print(f'ROC AUC Score: {roc_auc}')

# Feature importance
importance = model.feature_importance()
feature_names = X_train.columns
feature_importances = sorted(zip(feature_names, importance), key=lambda x: x[1], reverse=True)
print("Feature Importances:")
for feature, importance in feature_importances:
    print(f'{feature}: {importance}')

# Save model
joblib.dump(model, 'lightgbm_model.pkl')
