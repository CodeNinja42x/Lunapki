import pandas as pd

# Load the training data
train_data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/train_data.csv')

# Add more features to the training data
train_data['Price_Range'] = train_data['high'] - train_data['low']
train_data['Change'] = train_data['close'] - train_data['open']

# Save the enhanced data
train_data.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/enhanced_train_data.csv', index=False)
