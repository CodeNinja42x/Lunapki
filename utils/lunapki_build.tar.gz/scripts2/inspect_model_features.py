import joblib

# Path to the saved model
model_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/LightGBM_model.pkl'

# Load the model
best_model = joblib.load(model_path)

# Print model features
print("Model Features:", best_model.feature_name_)
