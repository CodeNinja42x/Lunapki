# add_timestamp.py
import pandas as pd

# Load the raw data
raw_data = pd.read_csv('data/raw_data.csv')

# Rename the 'Open time' column to 'timestamp'
raw_data.rename(columns={'Open time': 'timestamp'}, inplace=True)

# Save the updated raw data
raw_data.to_csv('data/raw_data.csv', index=False)
print("Timestamp column added and raw data saved.")
