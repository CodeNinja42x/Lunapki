import pandas as pd

# Load and inspect the data
data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/processed_data.csv')
print(data.columns)
