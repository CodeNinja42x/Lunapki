import pandas as pd
import numpy as np

# Load the data
data = pd.read_csv('data/input_data.csv')

# Convert date-time columns to numeric or remove them if not needed
if 'date_column' in data.columns:
    data['date_column'] = pd.to_datetime(data['date_column']).astype(int) / 10**9  # Example conversion to timestamp
    # or
    # data = data.drop('date_column', axis=1)

# Ensure all columns are numeric
data = data.select_dtypes(include=[np.number])

# Save the processed data
data.to_csv('data/processed_data.csv', index=False)

print("Data preprocessing completed and saved.")
