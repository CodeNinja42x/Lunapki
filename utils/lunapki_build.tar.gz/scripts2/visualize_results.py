import pandas as pd
import matplotlib.pyplot as plt

# Load the training data
train_data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/enhanced_train_data.csv')

# Prepare the features and target
X_train = train_data.drop(columns=['target', 'timestamp'])
y_train = train_data['target']

# Load the trained model
import joblib
model = joblib.load('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/final_lightgbm_model.pkl')

# Predictions
train_preds = model.predict(X_train)

# Plot actual vs predicted values
plt.scatter(y_train, train_preds)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs Predicted')
plt.show()
