import pandas as pd
from sklearn.model_selection import train_test_split

# Load the processed data
data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/processed_data_with_indicators.csv')

# Define features and target variable
features = ['open', 'high', 'low', 'close', 'volume', 'SMA', 'EMA', 'RSI', 'Bollinger_High', 'Bollinger_Low', 'RSI_diff', 'SMA_diff']
target = 'close'  # Adjust target variable if needed

# Ensure no missing values
data.dropna(inplace=True)

# Define a threshold to convert continuous target into binary (e.g., price increase or decrease)
threshold = data['close'].mean()
data['target'] = (data['close'] > threshold).astype(int)

# Split the data
X = data[features]
y = data['target']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save the split data
X_train.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_train.csv', index=False)
X_test.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_test.csv', index=False)
y_train.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_train.csv', index=False)
y_test.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_test.csv', index=False)

print("Data split and saved.")
