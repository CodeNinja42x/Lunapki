import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/processed_data_with_features.csv')

# Display basic statistics
print(data.describe())

# Check for NaN values
print(data.isna().sum())

# Plot distributions of features
data.hist(figsize=(12, 10), bins=30, edgecolor='black')
plt.tight_layout()
plt.show()

# Plot correlations excluding 'timestamp'
plt.figure(figsize=(12, 10))
correlation_matrix = data.drop(columns=['timestamp']).corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.show()

# Display the first few rows
print(data.head())
