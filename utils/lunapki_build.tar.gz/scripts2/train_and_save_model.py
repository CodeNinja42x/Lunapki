import pandas as pd
from lightgbm import LGBMClassifier
import joblib

# Load your training data
X_train = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/X_train.csv')
y_train = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/y_train.csv')

# Initialize and train the model
model = LGBMClassifier()
model.fit(X_train, y_train.values.ravel())  # Flatten y_train if necessary

# Save the trained model
joblib.dump(model, '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/LightGBM_model.pkl')

print("Model training and saving complete.")
