import joblib
import numpy as np

# Load the model
model = joblib.load('lightgbm_model.pkl')

# Generate or load new data
# For demonstration, we will use random data
new_data = np.random.rand(1, 20)  # Replace with actual data

# Predict using the loaded model
prediction = model.predict(new_data)
print(f"Prediction: {prediction}")
