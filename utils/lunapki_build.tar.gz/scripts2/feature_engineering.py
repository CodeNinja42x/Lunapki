import pandas as pd
import numpy as np
import ta

def create_features(df):
    df['return'] = df['close'].pct_change()
    df['volatility'] = df['return'].rolling(window=10).std().fillna(0)
    df['momentum'] = df['close'] - df['close'].shift(10)
    df['ma50'] = df['close'].rolling(window=50).mean().bfill()
    df['ma200'] = df['close'].rolling(window=200).mean().bfill()
    df['rsi'] = ta.momentum.RSIIndicator(df['close']).rsi().fillna(50)
    df['macd'] = ta.trend.MACD(df['close']).macd().fillna(0)
    df['macd_signal'] = ta.trend.MACD(df['close']).macd_signal().fillna(0)
    return df

if __name__ == "__main__":
    df = pd.read_csv('your_dataset.csv')
    df = create_features(df)
    print(df)
