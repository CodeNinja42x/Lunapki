import pandas as pd
import numpy as np

def calculate_technical_indicators(data):
    # Moving Average Convergence Divergence (MACD)
    data['EMA12'] = data['close'].ewm(span=12, adjust=False).mean()
    data['EMA26'] = data['close'].ewm(span=26, adjust=False).mean()
    data['MACD'] = data['EMA12'] - data['EMA26']
    data['Signal_Line'] = data['MACD'].ewm(span=9, adjust=False).mean()

    # Relative Strength Index (RSI)
    delta = data['close'].diff(1)
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    data['RSI'] = 100 - (100 / (1 + rs))

    # Bollinger Bands
    data['SMA20'] = data['close'].rolling(window=20).mean()
    data['stddev'] = data['close'].rolling(window=20).std()
    data['Bollinger_High'] = data['SMA20'] + (data['stddev'] * 2)
    data['Bollinger_Low'] = data['SMA20'] - (data['stddev'] * 2)

    # Additional indicators can be added here similarly

    return data

# Example usage
if __name__ == "__main__":
    # Load your data
    data = pd.read_csv('your_data.csv')
    data = calculate_technical_indicators(data)
    data.to_csv('enhanced_data.csv', index=False)
