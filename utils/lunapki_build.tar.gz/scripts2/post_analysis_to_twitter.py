import tweepy

# Replace these values with your actual Twitter API credentials
API_KEY = 'gUXOG3NO8pGh5IsrLJcjWwzCc'
API_SECRET_KEY = 'iQfqfCYDDXggfLPPjTKnfM4KcxN0SoK4a5hOqqIwkME88ZS0nj'
ACCESS_TOKEN = '1762949511649861632-tObIZwSMqLm9OxdMlDo41pDQT3t3gw'
ACCESS_TOKEN_SECRET = 'bi52skrPNi7kZU55c2KcyojG52vS7fv1fbDP8NHV0eqGJ'

# Authenticate to Twitter using OAuth 1.0a User Context
auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET_KEY, ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)

# Function to post analysis
def post_analysis(analysis_text):
    try:
        api.update_status(analysis_text)
        print("Analysis posted successfully!")
    except tweepy.TweepyException as e:
        print("Error while posting analysis:", e)

# Example analysis text
analysis_text = """
Daily Market Analysis:
- Bitcoin (BTC) is showing strong support at $30,000.
- Ethereum (ETH) has broken through the $2,000 resistance level.
- RSI indicates a potential upward trend for several altcoins.
#Crypto #Bitcoin #Ethereum #MarketAnalysis
"""

# Post the analysis to Twitter
post_analysis(analysis_text)
