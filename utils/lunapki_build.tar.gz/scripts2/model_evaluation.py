import pandas as pd
from sklearn.metrics import accuracy_score, roc_auc_score

# Load the actual values and predictions
actuals = pd.read_csv('data/actual_values.csv')
predictions = pd.read_csv('data/predictions.csv')

# Ensure both have the same number of samples
min_length = min(len(actuals), len(predictions))
actuals = actuals.iloc[:min_length]
predictions = predictions.iloc[:min_length]

# Calculate accuracy and ROC AUC score
accuracy = accuracy_score(actuals, predictions)
roc_auc = roc_auc_score(actuals, predictions)

print(f"Accuracy: {accuracy}")
print(f"ROC AUC Score: {roc_auc}")
