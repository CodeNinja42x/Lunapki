import requests
import time

API_URL = "http://127.0.0.1:5000/predict"
AUTH = ('admin', 'secret')

def get_predictions():
    data = [
        {
            "open": 100,
            "high": 110,
            "low": 90,
            "close": 105,
            "volume": 1500,
            "SMA": 102,
            "EMA": 103,
            "RSI": 60,
            "Bollinger_High": 115,
            "Bollinger_Low": 85,
            "RSI_diff": 5,
            "SMA_diff": 2,
            "MACD": 1.5,
            "Signal_Line": 1.0
        },
        {
            "open": 200,
            "high": 220,
            "low": 180,
            "close": 210,
            "volume": 3000,
            "SMA": 202,
            "EMA": 203,
            "RSI": 70,
            "Bollinger_High": 225,
            "Bollinger_Low": 175,
            "RSI_diff": 10,
            "SMA_diff": 5,
            "MACD": 2.0,
            "Signal_Line": 1.8
        }
    ]
    response = requests.post(API_URL, auth=AUTH, json=data)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code}")
        return None

def monitor_bot():
    while True:
        predictions = get_predictions()
        if predictions is not None:
            print(f"Predictions: {predictions}")
        else:
            print("Failed to get predictions.")
        time.sleep(60)  # Wait for 60 seconds before the next request

if __name__ == "__main__":
    monitor_bot()
