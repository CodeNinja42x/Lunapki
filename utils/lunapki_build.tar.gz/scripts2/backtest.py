import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from scripts2.feature_engineering import create_features
import pandas as pd

# Load historical data and prepare it
df = pd.read_csv('your_historical_data.csv')
df = create_features(df)
df = df.dropna()

# Load the trained model
import lightgbm as lgb
model = lgb.Booster(model_file='model.txt')

# Predict using historical data
X = df[['return', 'volatility', 'momentum', 'ma50', 'ma200', 'rsi', 'macd', 'macd_signal']]
df['predicted_close'] = model.predict(X)

# Print the predictions
print(df[['date', 'close', 'predicted_close']])
