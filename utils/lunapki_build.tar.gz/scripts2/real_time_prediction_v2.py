# scripts2/real_time_prediction_v2.py
import pandas as pd
import lightgbm as lgb

# Load real-time data
try:
    new_data = pd.read_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/realtime_data.csv')
except FileNotFoundError:
    print("File 'data/realtime_data.csv' not found.")
    new_data = pd.DataFrame([{
        'timestamp': 1, 'open': 100, 'high': 110, 'low': 90, 'close': 105, 'volume': 1000,
        'SMA': 102, 'EMA': 101, 'RSI': 70, 'Bollinger_High': 115, 'Bollinger_Low': 85
    }])

# Ensure the data has the required columns
required_columns = ['open', 'high', 'low', 'close', 'volume', 'SMA', 'EMA', 'RSI', 'Bollinger_High', 'Bollinger_Low']
for col in required_columns:
    if col not in new_data.columns:
        raise KeyError(f"Missing required column: {col}")

# Load model
model = lgb.Booster(model_file='lightgbm_model.txt')

# Predict
new_data_processed = new_data[required_columns]
prediction = model.predict(new_data_processed, predict_disable_shape_check=True)
print(f"Prediction: {prediction}")
