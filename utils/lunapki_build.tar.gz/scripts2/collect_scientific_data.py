# collect_scientific_data.py
import pandas as pd

# Sample data for physics laws and equations
data = {
    'Topic': ['Physics', 'Physics', 'Physics', 'Mathematics', 'Mathematics', 'Mathematics', 'Astronomy', 'Astronomy'],
    'Subtopic': ['Newton\'s Laws', 'Thermodynamics', 'Quantum Mechanics', 'Algebra', 'Calculus', 'Geometry', 'Kepler\'s Laws', 'Hubble\'s Law'],
    'Law/Equation': [
        'Newton\'s First Law: An object will remain at rest or in uniform motion in a straight line unless acted upon by an external force.',
        'Second Law of Thermodynamics: The total entropy of an isolated system can never decrease over time.',
        'Schrödinger Equation: iħ∂ψ/∂t = Ĥψ',
        'Quadratic Formula: x = (-b ± sqrt(b² - 4ac)) / 2a',
        'Fundamental Theorem of Calculus: If f is continuous on [a, b], and F is the antiderivative of f on [a, b], then ∫[a, b] f(x) dx = F(b) - F(a).',
        'Pythagorean Theorem: a² + b² = c²',
        'Kepler\'s First Law: The orbit of a planet is an ellipse with the Sun at one of the two foci.',
        'Hubble\'s Law: v = H₀d, where v is the velocity of a galaxy, H₀ is the Hubble constant, and d is the distance to the galaxy.'
    ],
    'Details': [
        'Newton\'s laws of motion are three physical laws that together laid the foundation for classical mechanics.',
        'The second law of thermodynamics states that the entropy of an isolated system always increases.',
        'The Schrödinger equation describes how the quantum state of a physical system changes over time.',
        'The quadratic formula provides the solution(s) to a quadratic equation.',
        'The fundamental theorem of calculus links the concept of differentiating a function with the concept of integrating a function.',
        'The Pythagorean theorem relates the lengths of the sides of a right triangle.',
        'Kepler\'s laws describe the motion of planets around the Sun.',
        'Hubble\'s law describes the expansion of the universe, with galaxies moving away from each other.'
    ]
}

# Convert the data to a DataFrame
df = pd.DataFrame(data)

# Save the DataFrame to a CSV file
df.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/scientific_data.csv', index=False)

print("Scientific data collected and saved successfully.")
