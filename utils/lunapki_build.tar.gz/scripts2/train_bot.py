import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from scripts2.feature_engineering import create_features
import pandas as pd
from sklearn.model_selection import train_test_split
import lightgbm as lgb

# Load and prepare the data
df = pd.read_csv('your_dataset.csv')
df = create_features(df)
df = df.dropna()

# Ensure we have enough data
if len(df) < 20:
    raise ValueError("Not enough data to train the model. Please add more data.")

# Split data into training and testing sets
X = df[['return', 'volatility', 'momentum', 'ma50', 'ma200', 'rsi', 'macd', 'macd_signal']]
y = df['close']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
train_data = lgb.Dataset(X_train, label=y_train)
params = {
    'learning_rate': 0.01,
    'num_leaves': 31,
    'objective': 'regression'
}
model = lgb.train(params, train_data, 100)
model.save_model('model.txt')

# Print the feature importances
print('Feature importances:', model.feature_importance())
