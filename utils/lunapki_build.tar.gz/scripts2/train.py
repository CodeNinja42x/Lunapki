import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
import lightgbm as lgb
import xgboost as xgb
import joblib
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler
import optuna

# Ensure the utils module is imported correctly
from utils import data_processing

print(dir(data_processing))  # This will list all the available functions and variables in data_processing module

# If 'preprocess_data' is in the list, it should be imported correctly
from utils.data_processing import preprocess_data

# Load and preprocess your data
data_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'training_data.csv'))
data = pd.read_csv(data_path)

# Basic data preprocessing
X = data.drop(columns=['target'])  # Replace 'target' with your target column name
y = data['target']

# Apply SMOTE to balance the dataset
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X, y)

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X_res, y_res, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Debug prints
print("Target distribution:")
print(y.value_counts())
print("X_train shape:", X_train.shape)
print("y_train shape:", y_train.shape)
print("X_test shape:", X_test.shape)
print("y_test shape:", y_test.shape)
print("First few rows of X_train:")
print(X_train[:5])
print("First few rows of y_train:")
print(y_train[:5])

# Optuna hyperparameter tuning for LightGBM
def objective_lgb(trial):
    param = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'boosting_type': 'gbdt',
        'learning_rate': trial.suggest_loguniform('learning_rate', 0.01, 0.1),
        'num_leaves': trial.suggest_int('num_leaves', 20, 150),
        'max_depth': trial.suggest_int('max_depth', 3, 15),
        'min_data_in_leaf': trial.suggest_int('min_data_in_leaf', 10, 50),
        'feature_fraction': trial.suggest_uniform('feature_fraction', 0.5, 1.0),
        'bagging_fraction': trial.suggest_uniform('bagging_fraction', 0.5, 1.0),
        'bagging_freq': trial.suggest_int('bagging_freq', 1, 7),
        'lambda_l1': trial.suggest_loguniform('lambda_l1', 1e-8, 10.0),
        'lambda_l2': trial.suggest_loguniform('lambda_l2', 1e-8, 10.0),
    }
    model = lgb.LGBMClassifier(**param)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    accuracy = accuracy_score(y_test, preds)
    return accuracy

study_lgb = optuna.create_study(direction='maximize')
study_lgb.optimize(objective_lgb, n_trials=50)

# Train LightGBM model with the best parameters
best_params_lgb = study_lgb.best_params
lgb_model = lgb.LGBMClassifier(**best_params_lgb)
lgb_model.fit(X_train, y_train)
lgb_preds = lgb_model.predict(X_test)

print("LightGBM Accuracy:", accuracy_score(y_test, lgb_preds))
print("LightGBM F1 Score:", f1_score(y_test, lgb_preds))
print("LightGBM Precision:", precision_score(y_test, lgb_preds))
print("LightGBM Recall:", recall_score(y_test, lgb_preds))

# Save the model
joblib.dump(lgb_model, '../models/lgb_model.pkl')

# Optuna hyperparameter tuning for XGBoost
def objective_xgb(trial):
    param = {
        'objective': 'binary:logistic',
        'eval_metric': 'logloss',
        'learning_rate': trial.suggest_loguniform('learning_rate', 0.01, 0.1),
        'max_depth': trial.suggest_int('max_depth', 3, 15),
        'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
        'subsample': trial.suggest_uniform('subsample', 0.5, 1.0),
        'colsample_bytree': trial.suggest_uniform('colsample_bytree', 0.5, 1.0),
        'lambda': trial.suggest_loguniform('lambda', 1e-8, 10.0),
        'alpha': trial.suggest_loguniform('alpha', 1e-8, 10.0),
    }
    model = xgb.XGBClassifier(**param)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    accuracy = accuracy_score(y_test, preds)
    return accuracy

study_xgb = optuna.create_study(direction='maximize')
study_xgb.optimize(objective_xgb, n_trials=50)

# Train XGBoost model with the best parameters
best_params_xgb = study_xgb.best_params
xgb_model = xgb.XGBClassifier(**best_params_xgb)
xgb_model.fit(X_train, y_train)
xgb_preds = xgb_model.predict(X_test)

print("XGBoost Accuracy:", accuracy_score(y_test, xgb_preds))
print("XGBoost F1 Score:", f1_score(y_test, xgb_preds))
print("XGBoost Precision:", precision_score(y_test, xgb_preds))
print("XGBoost Recall:", recall_score(y_test, xgb_preds))

# Save the model
joblib.dump(xgb_model, '../models/xgb_model.pkl')
