import joblib

# Load the trained model
model = joblib.load('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/final_lightgbm_model.pkl')

# Save the trained model for deployment
joblib.dump(model, '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/models/final_lightgbm_model.pkl')
