import pandas as pd

# Sample data for real-time prediction
data = {
    'timestamp': [1, 2, 3, 4, 5],
    'open': [100, 101, 102, 103, 104],
    'high': [110, 111, 112, 113, 114],
    'low': [90, 91, 92, 93, 94],
    'close': [105, 106, 107, 108, 109],
    'volume': [1000, 1100, 1200, 1300, 1400],
    'SMA': [102, 103, 104, 105, 106],
    'EMA': [101, 102, 103, 104, 105],
    'RSI': [70, 65, 60, 55, 50],
    'Bollinger_High': [115, 116, 117, 118, 119],
    'Bollinger_Low': [85, 86, 87, 88, 89]
}

df = pd.DataFrame(data)
df.to_csv('/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/realtime_data.csv', index=False)
