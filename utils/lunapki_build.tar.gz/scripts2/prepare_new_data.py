import pandas as pd

new_data_path = '/Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/data/new_data.csv'
new_data = pd.read_csv(new_data_path)

# Example of calculating moving averages
new_data['MA_5'] = new_data['close'].rolling(window=5).mean()
new_data['MA_10'] = new_data['close'].rolling(window=10).mean()
new_data['STD_5'] = new_data['close'].rolling(window=5).std()
new_data['Return'] = new_data['close'].pct_change()

# Save the updated new data
new_data.to_csv(new_data_path, index=False)
