import os

# Define a function for the entire workflow
def automate_workflow():
    # Data preprocessing
    os.system('python /Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/scripts2/preprocess_data.py')
    
    # Model training
    os.system('python /Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/scripts2/train_lightgbm_v2.py')
    
    # Model evaluation
    os.system('python /Users/gorkemberkeyuksel/Documents/GitHub/Lunapki/crypto_trading_bot/scripts2/evaluate_model.py')

# Run the workflow
automate_workflow()
